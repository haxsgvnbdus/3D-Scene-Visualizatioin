
Name: Han Ngo
Simple 3D Drawing
Simple 3D Visualization of houses 

BUILDING (OSX):
1. To compile, in terminal, type 'make'
2. To run, type './hw'

Screenshot of the program as attached.
Time to complete the assignment: 6-7hrs
 
Key bindings:
   a          Toggle axes
   arrows     Change view angle
   0          Reset view angle
   ESC        Exit

Time to complete the assignment: 6-7hrs
 
 
